import mongoose from "mongoose";
export const dbconnect = async (url) => {
  try {
    await mongoose.connect(url);
    console.log("DATABASE CONNECTED");
  } catch (error) {
    console.error("ERROR", error);
    process.exit(1); // Exit process if DB connection fails
  }
};
const { validateRegister, validateLogin } = require("../validation/authvalidation");
const bcrypt = require("bcryptjs"); 
//const { createUser, findUserByEmail } = require("../database/userQueries");callfunction from database 
//create user =code of creating new user 
//finduserbyemail = find user by email id 
// Then you call it like this:
async function register(req, res) {
  const validation = validateRegister(req.body);//calling validation function to check is everything is ok
  if (!validation.valid) return res.status(400).json({ message: validation.message });

  const { email, password, username, favouriteSubjects, state } = req.body;

  const existingUser = await findUserByEmail(email);//calling database function
  if (existingUser) return res.status(400).json({ message: "User already exists" });

  const hashedPassword = await bcrypt.hash(password, 10);//convertingpassword in hashcode
  const newUser = await createUser({ username, email, password: hashedPassword, favouriteSubjects, state });//calling database function

  res.status(201).json({
    message: "User registered successfully",
    user: { id: newUser.id, username: newUser.username, email: newUser.email },//sendind user details in respons 
  });
}

async function login(req, res) {
  const validation = validateLogin(req.body);//calling validation function to check is everything is ok
  if (!validation.valid) return res.status(400).json({ message: validation.message });

  const { email, password } = req.body;

  const user = await findUserByEmail(email);//calling database function to check user is exist or not 
  if (!user) return res.status(400).json({ message: "USER NOT FOUND BY THIS EMAIL" });

  const isMatch = await bcrypt.compare(password, user.password);//checking password 
  if (!isMatch) return res.status(400).json({ message: "INVALID PASSWORD" });

  const token = generateToken(user.id);//if every thing is ok then we assign a token to user
  res.json({ message: "Login successful", token });//sending token to frontend for furture login process
}

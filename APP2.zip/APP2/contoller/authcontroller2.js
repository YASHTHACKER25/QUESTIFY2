import {finduserbyemail,createuser} from "../database/authdatabase.js"
import {generateToken,generateRefreshToken} from "../utils/generatetoken2.js"
import { ValidateRegister,ValidateLogin } from "../validation/authvalidation2.js"
import bcrypt from "bcryptjs";
//register code:
export async function register(req,res){
    const validregister=ValidateRegister(req.body);
    if(!validregister.valid){
        return res.status(404).json({message:validregister.message})
    }
    const {Username,Email,Password,Faviouratesubjects,State}=req.body;
    const existinguser=await finduserbyemail(Email);
    if(existinguser){
        return res.status(400).json({message:"user already registered"});
    }
    const hashpassword=await bcrypt.hash(Password,10);
    const newUser=await createuser({
        Username,
        Email,
        Password:hashpassword,
        Faviouratesubjects,
        State
     })
     res.json({
        message:"Register Succsessful!",
        user: { id: newUser.id, username: newUser.username, email: newUser.email}
     })
}

//login code :
export async function login(req,res){
    const validlogin=ValidateLogin(req.body);
    if(!validlogin.valid){
        return res.status(404).json({message:validlogin.message})
    }
    const {Email,Password}=req.body
    const users=await finduserbyemail(Email);
    if(!users){
        return res.status(404).json({message:"USER NOT FOUND BY THIS EMAIL"});
    }
    const passcheck=await bcrypt.compare(Password,users.Password);//(HAMNANOPASSWORDNAME,SCHEMA NA ANDER HOY E PASSWORD NAME )
    if(!passcheck){
        return res.status(404).json({message:"INVALID PASSWORD"})
    }
  const accessToken = generateToken(users.id);
  const refreshToken = generateRefreshToken(users.id); 
  users.refreshToken = refreshToken;
  await users.save();
  res.json({
    message: "Login successful",
    accessToken,
    refreshToken
  });

}

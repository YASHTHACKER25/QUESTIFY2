// database/authdatabase.js
import User from "./models/User.js";

// ✅ find user by email
export async function finduserbyemail(email) {
  return await User.findOne({ Email: email });
}

// ✅ create new user
export async function createuser(userData) {
  const user = new User(userData);
  return await user.save();
}

// ✅ find user by id
export async function finduserbyid(id) {
  return await User.findById(id);
}

// ✅ update refresh token
export async function updateRefreshToken(userId, token) {
  return await User.findByIdAndUpdate(
    userId,
    { refreshToken: token },
    { new: true }
  );
}

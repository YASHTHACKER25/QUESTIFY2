import dotenv from "dotenv"
dotenv.config();
import express from "express"
import router from "./routes/authroutes.js"
import {dbconnect} from "./config/dbconnect.js"

const app=express();
app.use(express.json()); // parse JSON bodies
app.use(express.urlencoded({ extended: true })); // parse form data

//mongodb connection'
dbconnect("mongodb://127.0.0.1:27017/testdb");

//routes
app.use("/api",router);
//server control
app.listen(process.env.PORT,(err)=>{
    if(err)
    {
        console.log("error:"+err);
    }
    else
    {
        console.log("server started at port:"+process.env.PORT)
    }
});

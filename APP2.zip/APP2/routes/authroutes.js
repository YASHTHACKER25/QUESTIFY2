import express from "express"
import {login,register} from "../contoller/authcontroller2.js"
import {quetion} from "../contoller/quetioncontroller.js"
const router=express.Router();

router.post("/login",login);
router.post("/register",register);
router.post("/quetion",quetion)


export default router
import jwt from "jsonwebtoken"
import dotenv from "dotenv"
dotenv.config();
//const jwt=require("jsonwebtoken");
export function generateToken(userid){
    jwt.sign(/*values which we want to share but should send id for best practice*/{id:userid},process.env.ACSESS_TOKEN,{expiresIn:"1h"});
}
export function generateRefreshToken(userid){
    jwt.sign({id:userid},process.env.REFRESH_TOKEN,{expiresIn:"7d"});
}


// Helper function for email format check
function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// Helper function for password check
function isValidPassword(password) {
  // Minimum 8 characters, at least 1 uppercase, 1 lowercase, 1 number, 1 special character
  const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
  return re.test(password);
}

// Registration validation
function validateRegister(data) {
  const { username, password, email, favouriteSubjects, state } = data;

  if (!username || username.length < 3) {
    return { valid: false, message: "Username must be at least 3 characters" };
  }

  if (!password || !isValidPassword(password)) {
    return {
      valid: false,
      message:
        "Password must be at least 8 characters, include uppercase, lowercase, number, and special character",
    };
  }

  if (!email || !isValidEmail(email)) {
    return { valid: false, message: "Email must be valid" };
  }

  if (!Array.isArray(favouriteSubjects) || favouriteSubjects.length < 1) {
    return { valid: false, message: "Select at least one favourite subject" };
  }

  if (!state || state.trim() === "") {
    return { valid: false, message: "State is required" };
  }

  return { valid: true };
}

// Login validation
function validateLogin(data) {
  const { email, password } = data;

  if (!email || !isValidEmail(email)) {
    return { valid: false, message: "Email must be valid" };
  }

  if (!password || password.trim() === "") {
    return { valid: false, message: "Password is required" };
  }

  return { valid: true };
}

module.exports = { validateRegister, validateLogin };

export function quetionvalidation(data){
    

}
import 'dart:convert';
import 'package:http/http.dart' as http;

const String baseUrl = 'http://10.0.2.2:8000/api';

class HomeLogic {
  // Fetch questions according to subject_name and topic
  static Future<List<Map<String, dynamic>>> fetchQuestions({
    required String subjectName,
    required String topic,
  }) async {
    final url = Uri.parse('$baseUrl/questions?subject_name=$subjectName&topic=$topic');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body);
      return data.map((q) => q as Map<String, dynamic>).toList();
    } else {
      throw Exception('Failed to fetch questions');
    }
  }

  // Post a new question
  static Future<void> postQuestion({
    required String question,
    required String subjectName,
    required String topic,
    required String token,
  }) async {
    final url = Uri.parse('$baseUrl/questions');
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'question': question,
        'subject_name': subjectName,
        'topic': topic,
      }),
    );
    if (response.statusCode != 201) {
      throw Exception('Failed to post question');
    }
  }

  // Give answer to specific question
  static Future<void> giveAnswer({
    required String questionId,
    required String answer,
    required String token,
  }) async {
    final url = Uri.parse('$baseUrl/questions/$questionId/answers');
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'answer': answer}),
    );
    if (response.statusCode != 201) {
      throw Exception('Failed to post answer');
    }
  }
}

// Example logic-only usage (for testing, run in console environment)
void main() async {
  try {
    // Example usage: fetch for Programming/Flutter
    List<Map<String, dynamic>> questions = await HomeLogic.fetchQuestions(
      subjectName: 'Programming',
      topic: 'Flutter',
    );
    print('Questions:');
    for (var q in questions) {
      print(q);
    }
  } catch (e) {
    print('Error: $e');
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;

const String baseUrl = 'http://10.0.2.2:8000/api';

class QuestionLogic {
  // Submit a new question with subject_name and topic
  static Future<void> submitQuestion({
    required String question,
    required String subjectName,
    required String topic,
    required String token,
  }) async {
    final url = Uri.parse('$baseUrl/questions');
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'question': question,
        'subject_name': subjectName,
        'topic': topic,
      }),
    );
    if (response.statusCode != 201 && response.statusCode != 200) {
      throw Exception('Failed to submit question');
    }
  }

  // Fetch questions with subject_name and topic (just for completeness)
  static Future<List<Map<String, dynamic>>> fetchQuestions({
    required String subjectName,
    required String topic,
  }) async {
    final url = Uri.parse('$baseUrl/questions?subject_name=$subjectName&topic=$topic');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body);
      return data.map((q) => q as Map<String, dynamic>).toList();
    } else {
      throw Exception('Failed to fetch questions');
    }
  }
}

// Example logic-only usage (for testing, run in console environment)
void main() async {
  try {
    // Simulate posting a new question
    await QuestionLogic.submitQuestion(
      question: "What is a StatefulWidget in Flutter?",
      subjectName: "Programming",
      topic: "Flutter",
      token: "your_access_token_here",
    );
    print('Question submitted successfully!');
  } catch (e) {
    print('Error: $e');
  }
}

// File: lib/logics/register_logic.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class RegisterLogic {
  static const String baseUrl =
      'http://10.0.2.2:8000/api'; // Android emulator localhost

  static Future<void> registerUser({
    required BuildContext context,
    required String username,
    required String email,
    required String password,
    required List<String> favouriteSubjects,
    required String state,
  }) async {
    final url = Uri.parse('$baseUrl/register');

    // Validate non-empty fields here if desired, or rely on backend validation
    if (username.isEmpty ||
        email.isEmpty ||
        password.isEmpty ||
        favouriteSubjects.isEmpty ||
        state.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Please fill all fields')));
      return;
    }

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'Username': username,
          'Email': email,
          'Password': password,
          'Faviouratesubjects': favouriteSubjects,
          'State': state,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'] ?? 'Registration successful')),
        );

        // Optionally navigate to login or home screen
        // Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'] ?? 'Registration failed')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }
}

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
      theme: ThemeData(
        primaryColor: Color(0xFF93C5FD),
        fontFamily: 'Roboto',
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final List<Map<String, String>> questions = [
    {
      "question": "What is Flutter?",
      "subject_name": "Programming",
      "topic": "Flutter"
    },
    {
      "question": "Explain StatefulWidget.",
      "subject_name": "Programming",
      "topic": "Flutter"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Home",
                    style: TextStyle(
                      fontSize: 22,
                      color: Color(0xFF60A5FA),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF60A5FA),
                        shape: StadiumBorder(),
                        padding: EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8)),
                    child: Text("+ ASK QUESTION",
                        style: TextStyle(fontSize: 14, color: Colors.white)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                  padding: EdgeInsets.symmetric(horizontal: 18),
                  itemCount: questions.length,
                  itemBuilder: (context, i) => Padding(
                    padding: EdgeInsets.only(bottom: 16),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFEFF6FF),
                        border: Border.all(color: Color(0xFF60A5FA)),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: ListTile(
                        title: Text(
                          questions[i]['question'] ?? '',
                          style: TextStyle(fontSize: 18),
                        ),
                        subtitle: Text(
                          "${questions[i]['subject_name']} • ${questions[i]['topic']}",
                          style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                        ),
                        trailing: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xFFBAE6FD),
                            foregroundColor: Colors.black,
                            padding: EdgeInsets.symmetric(
                                horizontal: 18, vertical: 8),
                            shape: StadiumBorder(),
                            elevation: 0,
                          ),
                          child: Text(
                            "Give Answer",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  )),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Color(0xFFF1F5F9),
        selectedItemColor: Color(0xFF60A5FA),
        unselectedItemColor: Colors.black,
        currentIndex: 0,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined), label: "Home"),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_outline), label: "Profile"),
        ],
      ),
    );
  }
}

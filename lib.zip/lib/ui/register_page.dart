import 'package:flutter/material.dart';

import '../logic/register_logic.dart';

// FavouriteSubjectField widget as before
class FavouriteSubjectField extends StatefulWidget {
  final Function(List<String>) onChanged;
  const FavouriteSubjectField({Key? key, required this.onChanged})
      : super(key: key);

  @override
  State<FavouriteSubjectField> createState() => _FavouriteSubjectFieldState();
}

class _FavouriteSubjectFieldState extends State<FavouriteSubjectField> {
  final List<String> _options = ['Maths', 'Science', 'Physics', 'Other'];
  List<String> _selected = [];
  String? _otherText;

  void _showMultiSelectDialog() async {
    final tempSelected = List<String>.from(_selected);
    final result = await showDialog<List<String>>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) => AlertDialog(
            title: const Text('Select Favourite Subjects'),
            content: SingleChildScrollView(
              child: Column(
                children: [
                  ..._options.map((option) {
                    final isSelected = tempSelected.contains(option);
                    return CheckboxListTile(
                      title: Text(option),
                      value: isSelected,
                      onChanged: (checked) {
                        setStateDialog(() {
                          if (checked == true) {
                            tempSelected.add(option);
                          } else {
                            tempSelected.remove(option);
                          }
                        });
                      },
                    );
                  }).toList(),
                  if (tempSelected.contains('Other'))
                    Padding(
                      padding: const EdgeInsets.only(top: 12.0),
                      child: TextField(
                        decoration: const InputDecoration(
                          labelText: "Enter other subject",
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (text) {
                          setStateDialog(() {
                            _otherText = text;
                          });
                        },
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                child: const Text('Cancel'),
                onPressed: () => Navigator.pop(context, null),
              ),
              ElevatedButton(
                child: const Text('OK'),
                onPressed: () => Navigator.pop(context, tempSelected),
              ),
            ],
          ),
        );
      },
    );

    if (result != null) {
      setState(() {
        _selected = result;
        if (!_selected.contains('Other')) {
          _otherText = null;
        }
      });
      final allSubjects = List<String>.from(_selected);
      if (_selected.contains('Other') &&
          _otherText != null &&
          _otherText!.isNotEmpty) {
        allSubjects.remove('Other');
        allSubjects.add(_otherText!);
      }
      widget.onChanged(allSubjects);
    }
  }

  @override
  Widget build(BuildContext context) {
    final display =
    _selected.contains('Other') &&
        _otherText != null &&
        _otherText!.isNotEmpty
        ? [..._selected.where((e) => e != 'Other'), _otherText]
        : _selected;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Favourite Subjects",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: _showMultiSelectDialog,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade400),
              borderRadius: BorderRadius.circular(8),
              color: Colors.white,
            ),
            child: Text(
              display.isEmpty ? "Select subjects..." : display.join(', '),
              style: TextStyle(
                fontSize: 16,
                color: display.isEmpty ? Colors.grey : Colors.black,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// RegisterUI Stateful Widget managing form inputs
class RegisterUI extends StatefulWidget {
  final VoidCallback? onRegisterCallback;
  const RegisterUI({super.key, this.onRegisterCallback});

  @override
  State<RegisterUI> createState() => _RegisterUIState();
}

class _RegisterUIState extends State<RegisterUI> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _stateController = TextEditingController();
  List<String> _favouriteSubjects = [];

  bool _isRegistering = false;

  void _onFavouriteSubjectsChanged(List<String> subjects) {
    setState(() {
      _favouriteSubjects = subjects;
    });
  }

  Future<void> _handleRegister() async {
    setState(() {
      _isRegistering = true;
    });

    await RegisterLogic.registerUser(
      context: context,
      username: _usernameController.text.trim(),
      email: _emailController.text.trim(),
      password: _passwordController.text,
      favouriteSubjects: _favouriteSubjects,
      state: _stateController.text.trim(),
    );

    setState(() {
      _isRegistering = false;
    });
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _stateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff6f7fa),
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 18.0,
              vertical: 24.0,
            ),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(32),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 14,
                    spreadRadius: 1,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Icon(Icons.arrow_back_ios_new, color: Colors.blue),
                      Icon(Icons.arrow_forward_ios, color: Colors.blue),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Image.network(
                    "https://storage.googleapis.com/tagjs-prod.appspot.com/v1/MJPZiAVfzb/bfl3z99z_expires_30_days.png",
                    height: 200,
                  ),
                  const SizedBox(height: 22),
                  const Text(
                    'Register',
                    style: TextStyle(fontSize: 32, color: Colors.black),
                  ),
                  const SizedBox(height: 22),
                  TextField(
                    controller: _usernameController,
                    decoration: const InputDecoration(
                      labelText: "Username",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      labelText: "Email",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: "Password",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _stateController,
                    decoration: const InputDecoration(
                      labelText: "State",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FavouriteSubjectField(onChanged: _onFavouriteSubjectsChanged),
                  const SizedBox(height: 32),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: _isRegistering ? null : _handleRegister,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2196F3),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                        elevation: 3,
                      ),
                      child: _isRegistering
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text(
                        'Register',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
